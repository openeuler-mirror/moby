> **Warning**
> libnetwork was moved to https://github.com/moby/moby/tree/master/libnetwork
>
> libnetwork has been merged to the main repo of Moby since Docker 22.06.
>
> The old libnetwork repo (https://github.com/moby/libnetwork) now only accepts PR for Docker 20.10,
> and will be archived after the EOL of Docker 20.10.
