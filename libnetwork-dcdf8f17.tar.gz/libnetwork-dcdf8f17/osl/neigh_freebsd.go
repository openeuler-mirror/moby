package osl

// NeighOption is a function option type to set neighbor options
type NeighOption func()
