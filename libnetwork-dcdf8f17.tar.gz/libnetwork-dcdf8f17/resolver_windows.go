// +build windows

package libnetwork

func (r *resolver) setupIPTable() error {
	return nil
}
