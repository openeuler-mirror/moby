package ns

// File is present so that go build ./... is closer to working on Windows from repo root.
