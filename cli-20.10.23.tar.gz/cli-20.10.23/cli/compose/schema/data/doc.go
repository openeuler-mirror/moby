/*
	Package data contains all the Compose file JSON schemas, starting from v3.0.
*/

//
// +domain=docker.com

package data
